# -*- coding: utf-8 -*-
"""
ARCA - Ganancias - Artículo 30 (Deducciones Personales) - Parser único.

- Un solo archivo (sin common/, sin módulos separados)
- Sin hardcodear rutas: acepta --pdf o --pdf-dir + --year
- Robusto: parsea tablas con pdfplumber y tolera cambios de texto con regex
- Salida: JSON con items normalizados (keys estables para tu normalizador)

Requisitos:
    pip install pdfplumber

Uso:
    python art30_parser_single.py --year 2025 --pdf-dir "C:\\Users\\franl\\Desktop\\impuestos\\files" --out "outputs/raw/raw_art30_2025.json"
    python art30_parser_single.py --pdf "Deducciones-personales-art-30-liquidacion-anual-2024.pdf" --out out.json
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import pdfplumber


# =============================================================================
# Logging mínimo (sin dependencias, sin common/)
# =============================================================================

def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log_info(msg: str) -> None:
    print(f"[{_now()}] INFO  - {msg}")

def log_warn(msg: str) -> None:
    print(f"[{_now()}] WARN  - {msg}")

def log_error(msg: str) -> None:
    print(f"[{_now()}] ERROR - {msg}")


# =============================================================================
# Config / Mapeo de conceptos (regex tolerantes)
# =============================================================================

# Keys estables que vas a usar en el normalizador / excel
CONCEPT_PATTERNS: Dict[str, List[re.Pattern]] = {
    # Ganancia no imponible
    "ganancia_no_imponible": [
        re.compile(r"\bgananci(?:a|as)\s+no\s+imponible", re.I),
        re.compile(r"\bmni\b", re.I),
    ],

    # Cargas de familia
    "cargas_familia_conyuge": [
        re.compile(r"\bc[oó]nyuge\b", re.I),
    ],
    "cargas_familia_hijo": [
        re.compile(r"\bhijo\b(?!.*incapac)", re.I),  # hijo pero no "incapacitado"
        re.compile(r"\bhijo\/a\b(?!.*incapac)", re.I),
    ],
    "cargas_familia_hijo_incapaz": [
        re.compile(r"\bhijo.*incapac", re.I),
        re.compile(r"\bincapacitad[oa]\b", re.I),
    ],

    # Deducción especial - apartados
    "deduccion_especial_ap1": [
        re.compile(r"deducci[oó]n\s+especial.*apartado\s*1\b(?!.*nuev)", re.I),
        re.compile(r"deducci[oó]n\s+especial.*ap\.?\s*1\b(?!.*nuev)", re.I),
    ],
    "deduccion_especial_ap1_nuevos": [
        re.compile(r"apartado\s*1.*nuev", re.I),
        re.compile(r"nuevos\s+profesionales|emprendedores", re.I),
    ],
    "deduccion_especial_ap2": [
        re.compile(r"deducci[oó]n\s+especial.*apartado\s*2\b", re.I),
        re.compile(r"deducci[oó]n\s+especial.*ap\.?\s*2\b", re.I),
    ],
}

# Conceptos que pueden venir con texto en lugar de importe (ej: "Según...")
NON_NUMERIC_VALUE_HINTS = [
    re.compile(r"seg[uú]n", re.I),
    re.compile(r"deducciones\s+computables", re.I),
]


# =============================================================================
# Utilidades
# =============================================================================

def clean_number_ar(value: str) -> Optional[float]:
    """
    Convierte "4.507.505,52" -> 4507505.52
    Retorna None si no parece número.
    """
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None

    # Si parece "Según..." u otro texto, no es numérico
    for p in NON_NUMERIC_VALUE_HINTS:
        if p.search(s):
            return None

    # Aceptar $ y espacios
    s = s.replace("$", "").replace(" ", "").strip()

    # Detectar formato tipo 1.234.567,89 o 123,45 o 123
    if not re.search(r"\d", s):
        return None

    # Remover separadores de miles '.' y convertir ',' a '.'
    s2 = s.replace(".", "").replace(",", ".")
    try:
        return float(s2)
    except ValueError:
        return None


def normalize_text(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


def find_pdf_for_year(pdf_dir: Path, year: int) -> Optional[Path]:
    """
    Busca el PDF del Art.30 para el año.
    Priorizamos nombres típicos: "Deducciones-personales-art-30-liquidacion-anual-YYYY.pdf"
    pero sin depender 100% del filename.
    """
    if not pdf_dir.exists():
        return None

    candidates = list(pdf_dir.glob(f"*{year}*.pdf")) + list(pdf_dir.glob(f"*{year}*.PDF"))
    if not candidates:
        return None

    def score(p: Path) -> int:
        name = p.name.lower()
        sc = 0
        if "art-30" in name or "art30" in name:
            sc += 50
        if "deduccion" in name:
            sc += 30
        if "liquidacion" in name:
            sc += 10
        if str(year) in name:
            sc += 5
        return sc

    candidates.sort(key=score, reverse=True)
    return candidates[0]


def match_concept_key(concept_cell: str) -> Optional[str]:
    """
    Dado un texto de celda (columna concepto), detecta qué key corresponde.
    """
    text = normalize_text(concept_cell)
    if not text:
        return None

    # Intentar match por patterns
    for key, patterns in CONCEPT_PATTERNS.items():
        for pat in patterns:
            if pat.search(text):
                return key
    return None


# =============================================================================
# Parser
# =============================================================================

@dataclass
class ParseResult:
    anio: int
    fuente: str
    origen: str
    items: Dict[str, float]
    metadata: Dict[str, Any]
    warnings: List[str]
    missing: List[str]
    extra_found: List[str]


class Art30SingleParser:
    def __init__(self, year: int):
        self.year = int(year)

    def parse_pdf(self, pdf_path: Path) -> ParseResult:
        pdf_path = Path(pdf_path)
        warnings: List[str] = []
        items: Dict[str, float] = {}
        extra_found: List[str] = []

        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF no encontrado: {pdf_path}")

        log_info(f"Abriendo PDF: {pdf_path.name}")

        with pdfplumber.open(str(pdf_path)) as pdf:
            if not pdf.pages:
                raise ValueError("PDF sin páginas")

            for i, page in enumerate(pdf.pages):
                # Extraer tabla "CONCEPTO / IMPORTE"
                table = page.extract_table()
                if not table or len(table) < 2:
                    # fallback: intentar tablas con settings más permisivos
                    table = page.extract_table(
                        table_settings={
                            "vertical_strategy": "lines",
                            "horizontal_strategy": "lines",
                            "intersection_tolerance": 5,
                            "snap_tolerance": 3,
                            "join_tolerance": 3,
                            "edge_min_length": 3,
                            "min_words_vertical": 1,
                            "min_words_horizontal": 1,
                        }
                    )

                if not table:
                    warnings.append(f"No se detectó tabla en página {i+1}")
                    continue

                # Esperamos 2 columnas: concepto / importe
                for row_idx, row in enumerate(table):
                    if not row or len(row) < 2:
                        continue

                    concept_cell = normalize_text(row[0])
                    amount_cell = normalize_text(row[1])

                    if not concept_cell:
                        continue

                    # Saltar header
                    if row_idx == 0 and ("concepto" in concept_cell.lower() or "deducible" in concept_cell.lower()):
                        continue

                    key = match_concept_key(concept_cell)
                    val = clean_number_ar(amount_cell)

                    if key is None:
                        # Si hay un número y no sabemos el concepto, lo reportamos como extra
                        if val is not None:
                            extra_found.append(f"{concept_cell} = {amount_cell}")
                        continue

                    if val is None:
                        # Concepto reconocido pero no numérico (ej: doceava parte "según...")
                        warnings.append(f"Concepto '{key}' reconocido pero sin importe numérico: '{amount_cell}'")
                        continue

                    # Guardar (si aparece dos veces, nos quedamos con el último)
                    items[key] = val

        # Chequeo de esperados (no obligamos todos: depende del año/ARCA, pero lo reportamos)
        expected_keys = sorted(CONCEPT_PATTERNS.keys())
        missing = [k for k in expected_keys if k not in items]

        metadata = {
            "anio": self.year,
            "document_type": "art_30_deducciones_personales",
            "parse_date": datetime.now().isoformat(),
            "source_file": pdf_path.name,
            "pages": None,
        }

        try:
            with pdfplumber.open(str(pdf_path)) as pdf:
                metadata["pages"] = len(pdf.pages)
        except Exception:
            pass

        return ParseResult(
            anio=self.year,
            fuente="ARCA",
            origen="PDF_ART_30",
            items=items,
            metadata=metadata,
            warnings=warnings,
            missing=missing,
            extra_found=extra_found,
        )

    def parse(self, pdf_path: Optional[Path] = None, pdf_dir: Optional[Path] = None) -> Dict[str, Any]:
        """
        API simple para tu orquestador: devuelve dict listo para json.
        """
        if pdf_path is None:
            if pdf_dir is None:
                raise ValueError("Debés pasar pdf_path o pdf_dir")
            pdf_path = find_pdf_for_year(Path(pdf_dir), self.year)
            if pdf_path is None:
                raise FileNotFoundError(f"No encontré PDF para año {self.year} dentro de {pdf_dir}")

        result = self.parse_pdf(Path(pdf_path))

        return {
            "anio": result.anio,
            "fuente": result.fuente,
            "origen": result.origen,
            "items": result.items,
            "metadata": result.metadata,
            "warnings": result.warnings,
            "missing": result.missing,
            "extra_found": result.extra_found,
        }


# =============================================================================
# CLI
# =============================================================================

def main():
    ap = argparse.ArgumentParser(description="Parser único ARCA Art.30 (Deducciones personales)")
    ap.add_argument("--year", type=int, help="Año fiscal (ej: 2024)")
    ap.add_argument("--pdf", type=str, help="Ruta directa al PDF")
    ap.add_argument("--pdf-dir", type=str, help="Carpeta donde están los PDFs")
    ap.add_argument("--out", type=str, help="Ruta de salida JSON (opcional)")

    args = ap.parse_args()

    if not args.year:
        # Si pasás --pdf, intentamos inferir año del filename
        if args.pdf:
            m = re.search(r"(19|20)\d{2}", Path(args.pdf).name)
            if not m:
                raise SystemExit("Falta --year y no pude inferir año desde el nombre del PDF.")
            args.year = int(m.group(0))
        else:
            raise SystemExit("Falta --year (o pasar --pdf con año en el nombre).")

    parser = Art30SingleParser(args.year)

    pdf_path = Path(args.pdf) if args.pdf else None
    pdf_dir = Path(args.pdf_dir) if args.pdf_dir else None

    data = parser.parse(pdf_path=pdf_path, pdf_dir=pdf_dir)

    # Mostrar resumen
    log_info(f"Conceptos parseados: {len(data['items'])}")
    if data["missing"]:
        log_warn(f"Faltantes ({len(data['missing'])}): {data['missing']}")
    if data["extra_found"]:
        log_warn(f"Extras detectados con número ({len(data['extra_found'])}): {data['extra_found'][:3]}...")

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        log_info(f"JSON guardado en: {out_path}")
    else:
        print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
